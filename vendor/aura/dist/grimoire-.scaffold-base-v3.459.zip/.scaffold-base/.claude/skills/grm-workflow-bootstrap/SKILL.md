---
name: grm-workflow-bootstrap
description: Guided install and restore of the agentic-workflow skill set. Detects missing or drifted workflow skills/hooks, restores them from self-contained golden copies, then runs an interactive interview to fill project-specific placeholders (test/build/release commands, version file, doc-location map, branch names) while preserving the workflow structure. Use when onboarding a new project, after copying this scaffolding into an existing repo, or when a required workflow skill is missing or corrupted.
---

# Workflow-bootstrap

Equips a project's Claude agent with the workflow skill set and tailors it
to the project — without the user hand-editing a dozen files. It restores
skills from a **golden baseline** that is **generated**, not a committed
tree: `generate_golden.py` derives it from the pristine install (or extracts
a frozen archive), so restore works even if every sibling skill was deleted.

The golden baseline is **generic** (placeholder-laden, language-agnostic).
Bootstrap restores structure, then the interview customises it. It is a
point-in-time baseline frozen at install/version-change — not a
perpetually-synced mirror.

`manifest.md` (next to this file) is the source of truth for the canonical
set and the project-config placeholders.

> **Golden is generated (v3.49).** There is no longer a committed `golden/`
> tree. `generate_golden.py` derives the golden image from the flavor/install
> and writes it under the gitignored `.grimoire-golden/` cache. Throughout this
> guide, "the golden tree" / "`golden/…`" means the **resolved** tree returned
> by `resolve_golden()` (typically `.grimoire-golden/tree/`).

---

## Step 0 — Resolve / freeze the golden baseline

Before any inventory, materialize the golden baseline:

- **Fresh install (first bootstrap):** the just-copied files are pristine, so
  freeze a versioned baseline from them —
  `python3 .claude/skills/grm-workflow-bootstrap/generate_golden.py --freeze .`
  This writes `.grimoire-golden/golden-v{X.Y}.tar.gz` (the offline restore
  baseline). No network needed.
- **`--restore` / repair (later):** do **not** re-freeze from the now-customised
  tree (that would poison the baseline). Resolve the existing baseline instead —
  `… generate_golden.py --ensure-tree .` extracts the frozen archive (or, in the
  source/dogfood repo, generates from the `claude-code/` flavor) to
  `.grimoire-golden/tree/`.

All subsequent steps diff/restore against this resolved tree.

---

## Step 1 — Inventory

Read `manifest.md`. For each entry under "Restorable skills",
"Restorable infrastructure", "Restorable workflows", and "Restorable
paradigm content sets", classify the live copy by comparing the project
file against the resolved golden tree (Step 0):

| State | Meaning | Default action |
|---|---|---|
| **MISSING**   | No live file. | Restore from golden. |
| **PRISTINE**  | Live == golden (still has placeholders). | Restore not needed; flag for interview. |
| **CUSTOMISED**| Live differs, no project-config placeholders left. | Leave as-is. |
| **DRIFTED**   | Live differs *and* still has placeholders, or structurally diverged. | Ask before touching. |

Use `diff` against `<golden>/skills/<name>/SKILL.md`,
`<golden>/hooks/<file>`, `<golden>/settings.json`, and
`<golden>/workflows/<name>.js` (for any `.claude/workflows/*.js`), where
`<golden>` is the resolved tree from Step 0. Present the inventory as a table
before changing anything.

---

## Step 2 — Restore missing / confirmed files

- **MISSING** → copy the golden file into place
  (`.claude/skills/<name>/SKILL.md`, `.claude/hooks/<file>`,
  `.claude/settings.json`, `.claude/push-allowlist`,
  `.claude/workflows/<name>.js`). Create parent dirs as needed.
- **DRIFTED** → show the user a diff summary and ask whether to (a) keep
  their version, (b) overwrite from golden, or (c) keep theirs but
  re-apply only the interview placeholders. Never silently overwrite a
  customised skill.
- **settings.json** → if a live one exists and differs, do **not**
  clobber it. Show the hook-wiring block from golden and ask the user to
  merge, or merge it yourself if the live file has no conflicting keys.
  The golden `settings.json` also ships a scoped **`permissions.allow`**
  allowlist so the framework's own maintenance scripts run unattended
  without the auto-mode classifier re-prompting on every sync — **path-scoped
  to framework scripts only, never a blanket grant**:

  ```jsonc
  "permissions": {
    "allow": [
      "Bash($CLAUDE_PROJECT_DIR/.claude/skills/grm-sync-from-upstream/sync-from-upstream.sh:*)",
      "Bash(.claude/skills/grm-sync-from-upstream/sync-from-upstream.sh:*)",
      "Bash($CLAUDE_PROJECT_DIR/.claude/skills/grm-sync-from-source/sync-from-source.sh:*)",
      "Bash(.claude/skills/grm-sync-from-source/sync-from-source.sh:*)",
      "Write(.scaffold-upstream.conf)"
    ]
  }
  ```

  Merge these `allow` entries into the live `permissions.allow` (creating the
  block if absent); never widen beyond these framework-owned paths. The guard
  hooks remain the safety net — pre-authorizing the *already non-destructive*
  sync scripts (dry-run default, 3-way merge, backups, refuses `--apply` on a
  dirty tree) does not widen blast radius, it only stops re-prompting on a
  reversible operation. Granting these entries is a **user-confirmed** action
  (it edits `settings.json`); present the block and apply on approval.
- **PRISTINE / CUSTOMISED** → no copy.

- **workflows** → `.claude/workflows/<name>.js` is a Claude-Code-only
  artifact class (no Copilot equivalent) and read-only by convention, so
  it carries no interview placeholders — treat it like an infrastructure
  file: restore when MISSING, ask before overwriting when DRIFTED. See
  `docs/grimoire/design/release-planning-workflow-design.md` for the path
  convention and read-only safety contract.

- **paradigm content sets** → when `--restore` is requested (repair
  scenario), copy all files from `golden/paradigms/{supervised,weiss,noir}/`
  to `.claude/paradigms/{supervised,weiss,noir}/`. Then call
  `grm-work-paradigm-switch` (with no argument) to re-install the active
  paradigm's content into its stable active paths. The switch skill reads
  `work-paradigm.value` from `.claude/grimoire-config.json`; if the config
  is missing or the field is unset it defaults to `Supervised`. This step
  runs after all skill/hook restores so the content sets are in place
  before the switch skill needs them.

Restoration is a file copy only — no git operations, no commits.

---

## Step 2.5 — Seed upstream URLs (idempotent)

After restoring files from golden, seed the default upstream source URLs into
the project. This step runs for every bootstrap (new project or `--restore`)
and is safe to repeat — it never overwrites a value the project has already
set.

## Step 2.6 — Populate `.grimoire-source/` (idempotent)

After restoring files from golden and seeding upstream URLs, copy the canonical
framework source artifacts into `.grimoire-source/` at the **project root**.
This folder is the clean, read-only generation source that doc-generating skills
(`grm-source-to-design-docs`, `grm-design-doc-scaffold`, `grm-design-language-adapt`) prefer
over the live tree. See `.grimoire-source/README.md` for the full design rationale.

**What to copy** (conservative scope — only the artifacts the three consumer
skills read):

- All `SKILL.md` files from `.claude/skills/` → `.grimoire-source/skills/<name>/SKILL.md`
- Structural/operational docs under `docs/grimoire/` (if present) → `.grimoire-source/docs/grimoire/`

**Idempotency rules:**

1. If `.grimoire-source/` already exists and its contents match the golden/live
   sources → no-op (skip silently).
2. If `.grimoire-source/` is absent or stale → copy the artifacts in, creating
   parent directories as needed.
3. Never delete files from `.grimoire-source/` that are not in the copy source
   (additions are forward-compatible; old consumers may reference older paths).

**Important:** `.grimoire-source/` is gitignored and is a **runtime artifact**,
not a committed file. Do not stage or commit anything inside it.

**On `--restore`:** re-run this step unconditionally to ensure the generation
source matches the restored golden state.

---

## Step 2.7 — Register bundled MCP servers (idempotent, merge-safe)

Grimoire bundles an issue-tracker MCP server (v3.12). After restoring files,
register it so any MCP harness can use it:

1. **Server files** land via the Step 2 golden restore
   (`.claude/mcp-servers/lib/mcp_runtime.py`,
   `.claude/mcp-servers/issue-tracker/server.py`). If MISSING, restore from
   `golden/mcp-servers/`.
2. **`.mcp.json`** at the project root — **read-merge-write** the `mcpServers`
   object: add the `grimoire-issue-tracker` entry (`command: python3`,
   `args: [".claude/mcp-servers/issue-tracker/server.py"]`) **without clobbering**
   any server the project already declares. If `.mcp.json` is absent, create it
   from `golden/mcp.json`. (Cross-harness: Cursor `.cursor/mcp.json`, VS Code /
   Copilot `.vscode/mcp.json` — same shape.)
3. **Config** — `config-validate --migrate` backfills the default-on `mcp` block
   (`enabled` / `prefer-for-tracker`). No schema bump.
4. **Verify** — run `mcp_runtime.py --self-test` and `server.py --self-test`.

**On `--restore`:** re-run unconditionally; the merge is idempotent (an already
present `grimoire-issue-tracker` entry is left unchanged).

---

## Step 2.8 — Seed the dependency channel (idempotent, never-clobber)

Grimoire prescribes a uniform, release-channel-sourced **vendored** dependency
mechanism (v3.29 "Dependency Channel"): a published GitHub Release is the only
source for a first-party dependency, required deps are committed under
`vendor/<dep>/` so builds are offline, and the network is touched only at
*sync* time. Every new app seeds the three entry points by default. Design:
`docs/design/dependency-channel-design.md` §6.

1. **`vendor.toml`** at the project root — the human-authored intent file. Write
   it **only if MISSING**, copied from `golden/vendor.toml` (a commented stub:
   `schema_version = 1`, no active deps, an example `[deps.aura]` block showing
   every field). **Never clobber a present `vendor.toml`** — a non-empty live
   file carries the project's real dep declarations (the
   `.scaffold-upstream.conf` no-silent-clobber rule). If absent, restore the
   golden stub.
2. **`vendor.lock`** at the project root — the auto-generated resolved truth
   (JSON, do-not-hand-edit). Create it **programmatically only if absent** as the
   empty seed (it is *not* a bundled golden file — an empty golden file would
   trip the PRISTINE classification). Write exactly the canonical serialization
   the `grm-sync-deps` engine (`VendorLock.serialize`) emits — sorted keys, two-space
   indent, trailing newline:

   ```json
   {
     "deps": {},
     "schema_version": 1
   }
   ```

   If `vendor.lock` already exists (even empty), leave it untouched.
3. **`recipes.json`** — **ensure** the `grm-sync-deps` + `vendor-check` targets are
   present (read-merge-write; never clobber an existing binding). These ride the
   `recipe.py` `INTERFACE` (`INTERFACE_VERSION 3`, v3.29). If a target is absent,
   add it as an unimplemented stub (`{"command": null, "implemented": false}`)
   bound when the project wires the engine; if present, leave it as-is. If
   `recipes.json` itself is absent, the recipe-stubbing step that creates it
   already includes these verbs from the `INTERFACE` — this step is then a no-op
   confirmation.
4. **`.gitignore`** — **ensure** the line `.sync-deps-staging/` is present (the
   transient fixed staging dir the `grm-sync-deps` engine creates and cleans per run;
   ignored as a safety net against an interrupted run). Read-merge-write; if the
   line is already present, no-op. (`vendor/<dep>/` is **committed**, not
   ignored — that is the core "fully offline" principle; `dist/` stays ignored as
   producer output.)

**Idempotency contract:** re-running this step on an initialized app is a
**no-op** — a customized `vendor.toml` is never overwritten, an existing
`vendor.lock` is never rewritten, present recipe verbs are left untouched, and
an already-present ignore line is not duplicated.

**On `--restore`:** re-run unconditionally; every sub-step is guarded
(missing-only / ensure-present), so the restore never clobbers live dependency
declarations.

---

## Step 3 — Guided interview

Ask the project-config questions with `AskUserQuestion`. Skip any whose
answer is already evident (e.g. command is in CLAUDE.md, version file
obvious from repo ecosystem) — confirm rather than re-ask. Batch related
questions; offer a sensible default as the first option where one exists.

1. **Test command** — how the full suite runs (`npm test`, `pytest`,
   `cargo test`, `go test ./...`, …).
2. **Build command** — release build (`npm run build`, `make`, `cargo
   build --release`, …).
3. **Release command** — the one-shot release recipe (`npm version
   minor && npm publish`, `just release`, `make release VERSION=…`).
3a. **Quality commands (optional, v1.26 merge gate)** — type-check
   (`mypy`, `tsc --noEmit`, `cargo check`, `go vet`), lint
   (`ruff`, `eslint`, `clippy`), and coverage (`pytest --cov`, …). Each is
   optional; a blank answer leaves that gate off. Captured into the
   `code-quality` block of `.claude/grimoire-config.json` (defaults
   `audit-gate: warn`, `auto-reviewer: noir`, `coverage-threshold: null`,
   `typecheck: build`). See `docs/grimoire/design/merge-gate-quality-design.md`.
4. **Version file + field** — where the authoritative version lives and
   its format (`package.json` → `"version"`, `Cargo.toml` → `[package]
   version`, `VERSION` file, …).
5. **Doc-location map** — the real paths for architecture / UX / feature
   / versioning docs (rows in `grm-repo-reference`).
6. **Integration branch name** — the staging trunk (default `dev`).
7. **Release branch name** — the production trunk (default `main`).
8. **First roadmap entry** — first version number + one-line theme.
9. **GUI presence** — whether this project has (or will have) a user
   interface.

   **Auto-detection (run before asking).** Scan the repo root (and one
   level of obvious source directories) for GUI-framework signals. The
   scan is **read-only and offline** — no network calls, no file writes.
   Use the results only to pre-select a default and surface evidence;
   the user's answer is always authoritative.

   *Signal table (rows are ordered by precedence — row 1 is strongest):*

   | # | Signal source | Signal | Inferred stack | GUI? |
   |---|---|---|---|---|
   | 1 | Native/mobile dep + extension | `*.swift` + `*.xcodeproj`/`Package.swift` with a UI dep | SwiftUI / UIKit (Apple) | Yes |
   | 2 | Native/mobile dep + extension | `*.kt`/`*.java` + `AndroidManifest.xml` | Android (Kotlin/Java) | Yes |
   | 3 | Native/mobile dep + extension | `Info.plist`, `*.storyboard`, `ios/` + `android/` dirs | native/mobile app shell | Yes |
   | 4 | File extension | `*.xaml` | WPF / WinUI / Avalonia (.NET) | Yes |
   | 5 | File / dep | `pubspec.yaml` with `flutter` | Flutter (cross-platform) | Yes |
   | 6 | Cargo.toml dep | `egui`, `iced`, `tauri`, `slint` | Rust GUI / Tauri | Yes |
   | 7 | Dep / import | `PyQt*`, `PySide*`, `tkinter`, `wxPython`, `kivy` | Python desktop GUI | Yes |
   | 8 | `package.json` deps | `react`, `react-dom` | React (web) | Yes |
   | 9 | `package.json` deps | `react-native`, `expo` | React Native (mobile) | Yes |
   | 10 | `package.json` deps | `vue` | Vue (web) | Yes |
   | 11 | `package.json` deps | `svelte`, `@sveltejs/kit` | Svelte / SvelteKit (web) | Yes |
   | 12 | `package.json` deps | `@angular/core` | Angular (web) | Yes |
   | 13 | `package.json` deps | `solid-js` | SolidJS (web) | Yes |
   | 14 | `package.json` deps | `electron` | Electron (desktop, JS) | Yes |
   | 15 | `package.json` deps | `next`, `nuxt`, `@remix-run/*`, `astro`, `gatsby` | meta-framework over detected base (Next→React, Nuxt→Vue, …) | Yes |
   | 16 | TUI dep | `rich`, `textual`, `blessed`, `bubbletea`, `ratatui` | terminal UI (TUI) | Yes (TUI) |
   | 17 | Config file | `vite.config.*`, `next.config.*`, `nuxt.config.*`, `svelte.config.*`, `angular.json`, `astro.config.*` | confirms/disambiguates the web stack | Yes |
   | 18 | Config file | `tailwind.config.*`, `postcss.config.*` | web styling (corroborating, not deciding) | (boost web) |
   | 19 | Server-only deps, no view layer | `express`/`fastify`/`flask`/`gin` with **no** rows 1–18 hit | likely headless service | Lean "No, headless" |
   | 20 | Library manifest, no app entry | published-package shape, no UI dep | likely headless library | Lean "Not yet" / "No" |

   *Precedence (deterministic, highest wins):*

   1. **Explicit native/mobile + framework dep** (rows 1–3) — strongest;
      names a concrete platform.
   2. **Declared runtime dep in a manifest** (rows 4–16) — a dependency
      the project chose to install.
   3. **Config-file presence** (rows 17–18) — corroborates/disambiguates
      a manifest hit; a lone config file with no dep is a weak signal.
   4. **File-extension census** — used to disambiguate between multiple
      manifest hits or when no manifest exists.
   5. **Negative/headless leans** (rows 19–20) — applied only when **no**
      positive GUI signal (rows 1–18) fired.

   Meta-frameworks (row 15) resolve their base via the underlying dep
   (Next ⇒ React, Nuxt ⇒ Vue) and report the meta-framework as the
   stack hint. When two peer web frameworks both appear (e.g. a monorepo),
   report the highest-confidence single guess and list the runner-up so
   the user can choose.

   The **stack-hint** yielded by detection is written verbatim into the
   `{ux-demo-stack}` slot (e.g. "React (web)", "SwiftUI", "Textual
   (TUI)") so `grm-ux-demo-build` can produce a stack-pure demo.

   *Confidence levels (changes presentation only — never removes the
   requirement to confirm):*

   - **High** (a framework dep + corroborating config or extensions):
     pre-select "Yes", pre-fill the stack hint. Phrase the prompt as
     *"Detected a React (web) UI — confirm or change."*
   - **Medium** (a single weak signal, e.g. a lone config file):
     pre-select the leaning option but phrase as a question; surface the
     evidence found.
   - **Low / none** (no signal, or conflicting peers): ask the cold
     question below with no pre-selection; offer the runner-up list if
     peers conflicted.

   Hard rules:
   - Detection **pre-fills the default and surfaces its evidence**;
     it never skips Q9 or auto-commits an answer.
   - Detection **never writes a file** — it only feeds Q9. All file
     changes flow through the existing Step 4 patch table unchanged.
   - When detection leans headless/deferred (rows 19–20) it still routes
     through the normal "Not yet" / "No, headless" outcomes; it never
     silently skips the UX tier.
   - **Web-app persistence (v3.26)** is the *one* exception to "detection
     never writes config": it writes the `web-app` block, but only **after**
     the user confirms — see the persistence sub-step below. It persists the
     **confirmed** answer, never the detected guess.

   Use `AskUserQuestion` with three options (pre-selected per detection
   result above):
   - **Yes** → ask two follow-up questions using `AskUserQuestion`:
     - *Design-language source*: upstream URL (default
       `https://github.com/rhohn94/design-language` — CONFIRM-pending
       placeholder; verify with project owner) or `local` for strict-local
       mode. Step 2.5 already seeded this value; confirm or override it here.
       Fills `{design-language-source}` and `{design-language-source-url}`
       (see Step 4).
     - *Primary GUI stack / framework hint*: the project's main GUI
       framework (e.g. "SwiftUI", "React", "Qt Widgets") — pre-filled
       from the detection stack-hint above when confidence is High or
       Medium; confirm or override. Fills `{ux-demo-stack}`, consumed by
       `grm-ux-demo-build` to build a stack-pure demo.

     **Web-app persistence (v3.26 — `web-app-support-design.md` §2.4).** Once
     the confirmed stack is in hand, decide the web-app fact from the *web
     slice* of the Q9 evidence (the narrower "browser-delivered, server-hosted
     app?" question — not the GUI boolean):

     - **Web slice** — rows 8–13/15 (browser/meta web frameworks), corroborated
       by rows 17–18, **or** a server web framework (Flask/Django/Express/
       FastAPI/Rails/Gin) serving HTML/templates → **persist** `web-app =
       { value: "yes", stack: <confirmed stack> }` into
       `.claude/grimoire-config.json` via a **pure-data write** (write only the
       `web-app` key; leave every other field and `schema-version` untouched —
       the same write `grm-web-app-apply` uses, no `schema-version` bump).
     - **Non-web GUI** — native/desktop/mobile (rows 1–7/9/14) or TUI (row 16)
       → persist **nothing**; the block stays **absent** even though
       `GUI = Yes`.
     - **If onboarding already wrote the block** (it passed a confirmed web-app
       answer in its §4.2 handoff) this step is a **no-op** — never re-detect or
       overwrite a confirmed answer.

     This is *after* the user confirms, never as part of detection. The persist
     makes the `grm-quick-start-template` Step 1 project-type read **real**: after
     bootstrap, the `web` profile resolves from the persisted `web-app` block
     without re-asking.
   - **Not yet** → record the deferral; Step 4 appends the placeholder
     row to `docs/roadmap.md` under `## Backlog`. No design-language
     adoption now. The `web-app` block stays **absent** (the default).
   - **No, headless** → mark the UX tier N/A for this project. Note it
     in the Step 5 report. Do **not** fabricate any files; skip
     `grm-design-language-adapt` and `grm-ux-demo-build` for this project's
     bootstrap. The `web-app` block stays **absent** (the default).

Record answers in a working table; echo it back before patching.

---

## Step 4 — Patch placeholders

Apply answers **only** to the project-config tokens in `manifest.md`.
Never substitute a runtime template token (`{feature}`, `{branch}`,
`{model}`, `{effort}`, `{short-sha}`, …) — those are filled per-use by
agents at runtime; replacing them breaks the templates.

| Answer | Files to patch |
|---|---|
| Active paradigm | `CLAUDE.md` — fill the `## Paradigm` stamp's `{ACTIVE}` token (see Rules below) |
| Test command  | `CLAUDE.md`, `grm-release-phase`, `grm-release-phase-merge` — every `{test-command}` |
| Build command | `CLAUDE.md`, `grm-release-phase`, `grm-release-phase-merge` — every `{build-command}` |
| Release command | `CLAUDE.md`, `grm-project-release`, `docs/grimoire/version-design.md` — every `{release-command}` |
| Type-check command | `CLAUDE.md` commands table — `{typecheck-command}` (blank ⇒ set `code-quality.typecheck.value: "off"`; folded into the build gate otherwise) |
| Lint command | `CLAUDE.md` commands table — `{lint-command}` (blank ⇒ no lint gate) |
| Coverage command | `CLAUDE.md` commands table — `{coverage-command}` (blank ⇒ `code-quality.coverage-threshold.value: null`) |
| Version file + field | `docs/grimoire/version-design.md` §3 — `{path/to/version/file}` / `{field name or format}` |
| Doc-location map | `grm-repo-reference` SKILL.md — replace the map rows; keep the table shape |
| Integration / release branch names | `hooks/protected-branch-guard.sh` `PROTECTED_RE` (and any prose naming `dev`/`main`/`version/*` in CLAUDE.md + integration-workflow.md) |
| First roadmap entry | `docs/roadmap.md` — replace the placeholder `v1.0` block with the real first version + theme |
| GUI: Yes → design-language source | `docs/design/ux/design-language.md` front-matter `source:` — set to `upstream` or `local` (default `upstream`) |
| GUI: Yes → design-language source URL | `docs/design/ux/design-language.md` front-matter `source-url:` — set to the entered URL (default `https://github.com/rhohn94/design-language`) |
| GUI: Yes → GUI stack hint | `docs/design/ux/design-language.md` §Design preamble — add a "Primary stack: `{ux-demo-stack}`" note for `grm-ux-demo-build` to read; also echo in the Step 5 report |
| GUI: Not yet → deferral | `docs/roadmap.md` `## Backlog` section — append `- UX design language: deferred until v{X.Y}` (leave `{X.Y}` as a user-facing placeholder to fill at release-planning time) |
| GUI: No, headless → N/A | Report only — no files changed; note that `grm-design-language-adapt` and `grm-ux-demo-build` are skipped for this project |

Rules:
- If branch names stay `dev`/`main`, leave `PROTECTED_RE` untouched.
- If a target file is absent (fresh project with no `CLAUDE.md`/`docs`
  yet), note it in the report — do **not** fabricate the file here;
  point the user at the scaffolding README setup checklist.
- Edit in place; preserve surrounding structure and formatting exactly.
- **Active-paradigm stamp (idempotent).** In `CLAUDE.md`, fill the
  `## Paradigm` stamp from `work-paradigm.value` in
  `.claude/grimoire-config.json` (default `Supervised` if missing/unset).
  The golden block is:
  ```markdown
  > **Paradigm:** {ACTIVE} — one of Supervised · Weiss · Noir.
  > Switch via the `grm-work-paradigm-switch` skill. See `.claude/paradigms/README.md`.
  ```
  Match the `> **Paradigm:** …` line and substitute the value (whether it is
  the literal `{ACTIVE}` token on a fresh golden copy or a previously-filled
  name on re-run) — **match-and-replace, never append a duplicate block**.

## Step 4.5 — Always-deliver the paradigm breadcrumb (idempotent)

Regardless of selected paradigm and independent of `--restore`, ensure the
breadcrumb index is present so all three paradigm names stay greppable
in-project (the lean install is unchanged — only this small always-present
index is added):

- Rewrite `.claude/paradigms/README.md` from
  `golden/paradigms/README.md` (overwrite — it is a static index with no
  project-config tokens, so rewriting from golden is the idempotent operation).
  Create the `.claude/paradigms/` directory if absent.

---

## Step 4.6 — Seed docs hierarchy stubs (idempotent, never-clobber)

After delivering the paradigm breadcrumb and independent of `--restore`,
seed the docs hierarchy index stubs so every new project has navigable
entry points from day one. Both files are minimal stubs — they are never
overwritten if a project-customised version already exists.

- **`docs/README.md`** — if MISSING, copy from
  `golden/docs/README.md` (the docs root index with `<!-- docs-map:begin -->` /
  `<!-- docs-map:end -->` markers). Create the `docs/` directory if absent.
- **`docs/grimoire/README.md`** — if MISSING, copy from
  `golden/docs/grimoire/README.md` (the Grimoire-internal tier index). Create
  the `docs/grimoire/` directory if absent.

**Never-clobber rule:** if either file already exists (even with content that
differs from golden), leave it unchanged. This matches the
`.scaffold-upstream.conf` / `vendor.toml` no-silent-clobber contract — the
golden copy is a seed, not an enforced template.

**On `--restore`:** re-run this step. The never-clobber rule still applies —
`--restore` does not override a project-customised stub.

---

## Step 5 — Verify & report

1. Re-grep for project-config placeholders; none of the Step-4 tokens
   should remain in patched files. In particular, `CLAUDE.md` carries a single
   `## Paradigm` stamp with a concrete name (no leftover `{ACTIVE}`), and
   `.claude/paradigms/README.md` is present and names all three paradigms.
2. Confirm the four hooks are referenced in `.claude/settings.json`.
3. If `--restore` was run: confirm `.claude/paradigms/{supervised,weiss,noir}/`
   exist and are populated; confirm `grm-work-paradigm-switch` ran to completion.
4. Report:
   - **Restored**: files copied from golden (by path).
   - **Patched**: tokens filled, with the values used.
   - **Untouched**: customised skills left alone.
   - **Needs human input**: anything that couldn't be resolved
     (missing CLAUDE.md, ambiguous doc map, etc.).
5. Suggest next steps: `grm-source-to-design-docs` if `docs/design/` is empty,
   then `grm-release-planning` when a release is being scoped.

No git operations. The user reviews and commits.

---

## Reference (load on demand)

- `When to use this skill` — see `reference.md`
- `Anti-patterns` — see `reference.md`
- `Grimoire Framework URL (`.scaffold-upstream.conf`)` — see `reference.md`
- `Aura design language URL (`docs/design/ux/design-language.md`)` — see `reference.md`
