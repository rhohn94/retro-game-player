# .grimoire-source/

**Generation source — read-only, do not edit.**

This folder holds clean, unmodified copies of the framework artifacts that
doc-generating skills consume as input. It is populated at bootstrap time by
`grm-workflow-bootstrap` and refreshed by `grm-sync-from-upstream` / `grm-sync-from-source`
whenever the framework itself updates.

## Purpose

Doc-generating skills need a **trustworthy, stable input** that is decoupled
from whatever the live working tree happens to be doing (mid-edit, partially
migrated, carrying local customizations). `.grimoire-source/` provides that:
a clean snapshot of the canonical framework source, separate from the live tree.

## Layout

Files mirror the shipped layout under this root so a consumer can resolve an
input by its normal relative path:

```
.grimoire-source/
  skills/<name>/SKILL.md      # canonical skill sources
  docs/grimoire/              # structural / operational docs
  …
```

Only the artifacts the three consumer skills actually read are included — this
is **not** a full mirror of the repo.

## Consumers (read-only)

| Skill | What it reads |
|---|---|
| `grm-source-to-design-docs` | Skill/doc set to synthesize `docs/design/` for an existing project |
| `grm-design-doc-scaffold` | House-layout/section sources when scaffolding a new design doc |
| `grm-design-language-adapt` | Design-language source when producing a per-project adaptation |

All consumers treat this folder as **read-only**. No skill or task agent writes
into it; it is only written by bootstrap and sync operations.

## How it differs from `golden/`

| | `.../workflow-bootstrap/golden/` | `.grimoire-source/` |
|---|---|---|
| **Purpose** | Restore baseline — bytes `workflow-bootstrap --restore` / `grm-hard-reset` write back | Generation source — clean input that doc-generating skills read |
| **Direction** | Written *out* to active paths on restore | Read *in* by generators; never written to active paths |
| **Consumers** | `grm-workflow-bootstrap`, `grm-hard-reset`, `grm-install-doctor` | `grm-source-to-design-docs`, `grm-design-doc-scaffold`, `grm-design-language-adapt` |
| **On missing** | Restore cannot proceed (fail-closed) | Generators fall back to live tree with a warning (fail-safe) |

## Population

`grm-workflow-bootstrap` copies the canonical source artifacts here at install time.
`grm-sync-from-upstream` and `grm-sync-from-source` refresh it when the framework
updates. It is **gitignored** — it is a runtime artifact, not a committed file.
Re-run bootstrap or sync to repopulate after a fresh clone.

## Fail-safe fallback

If this folder is absent (e.g. on a fresh clone before bootstrap has run),
consumer skills fall back to the live tree with a one-line warning. Generation
still works; it just reads from a potentially-dirty source. Run
`grm-workflow-bootstrap` to populate `.grimoire-source/` and eliminate the warning.
